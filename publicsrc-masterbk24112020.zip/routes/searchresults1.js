
const express = require('express');
const router = express.Router();
const axios = require('axios');
var request = require('request');

router.post('/',(req, res) => {

  const { legalgrantingdate } = req.body;
  const { legal_granting_date_day    } = req.body;
  const { legal_granting_date_month  } = req.body;
  const { legal_granting_date_year   } = req.body;
  const { legal_granting_date_day1   } = req.body;
  const { legal_granting_date_month1 } = req.body;
  const { legal_granting_date_year1  } = req.body;
  
  radio_legalgrantingdate = legalgrantingdate;
  date_legal_granting_date_day = legal_granting_date_day  ;
  date_legal_granting_date_month = legal_granting_date_month  ;
  date_legal_granting_date_year = legal_granting_date_year  ;
  date_legal_granting_date_day1 = legal_granting_date_day1 ;
  date_legal_granting_date_month1 = legal_granting_date_month1  ;
  date_legal_granting_date_year1 = legal_granting_date_year1  ;

  console.log("legalgrantingdate:" + legalgrantingdate);
  console.log("date_legal_granting_date_day:" + date_legal_granting_date_day);
  console.log("date_legal_granting_date_month:" + date_legal_granting_date_month);
  console.log("date_legal_granting_date_year:" + date_legal_granting_date_year);

  console.log("date_legal_granting_date_day1:" + date_legal_granting_date_day1);
  console.log("date_legal_granting_date_month1:" + date_legal_granting_date_month1);
  console.log("date_legal_granting_date_year1:" + date_legal_granting_date_year1);

  const data = 
    {
      "beneficiaryName": text_beneficiaryname,
      "subsidyMeasureTitle": "",
      "subsidyObjective": check_subsidyobjective,
      "spendingRegion": "",
      "subsidyInstrument": check_subsidyinstrument,
      "spendingSector":check_spendingsector
    
  };
  
  createUser = async () => {
      try {
          const res = await axios.post('https://subsidy-search-service.azurewebsites.net/searchResults', data);
          console.log(`Status: ${res.status}`);
          console.log('Body: ', res.data);
          searchawards = res.data
          var searchawards_api = res.data;
          console.log("searchawards" + searchawards_api );
          const seachawardstring = JSON.stringify(searchawards_api );
          console.log('seachawardstring' + seachawardstring );
          const seachawardJSON = JSON.parse(seachawardstring );
          console.log('seachawardJSON ' + seachawardJSON.awards[0]  );
          console.log(searchawards.awards[0].beneficiary.beneficiaryType);
          console.log(searchawards.awards[0].subsidyFullAmountExact);
      } catch (err) {
          console.error(err);
      }
  };
  
  createUser();
  setTimeout(() => {
      res.render('publicusersearch/searchresults1')
     }, 8000);

  });

  router.get('/',(req, res) => {
    res.render('publicusersearch/searchresults1')
  });


module.exports = router;
