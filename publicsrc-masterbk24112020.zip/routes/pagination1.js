// ********************************************************************
// Gov.UK public user search subsidy awards beneficiary name routing 
// ********************************************************************



const express = require('express');
const router = express.Router();

router.post('/',(req, res) => {
  
    res.render('publicusersearch/pagination1')
  });

  router.get('/',(req, res) => {
    // const { paginationlink } = req.body;
    //console.log("paginationlink id :" + paginationlink);
    res.render('publicusersearch/pagination1')




  });


module.exports = router;
